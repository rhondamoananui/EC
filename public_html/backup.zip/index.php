<?php 
	$root = realpath($_SERVER["DOCUMENT_ROOT"]);
	include "php/start.php";
	include "php/components_display_functions.php";
	$data = new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB);
	if(isset($_POST['usernameField']) && isset($_POST['passwordField']) && $_POST['passwordField']!='' && $_POST['usernameField']!='' && $_POST['usernameField']!='Nickname or E-mail' && $_POST['passwordField']!="Password")
	{
		$result = $data -> query('SELECT COUNT(*) AS ofUsers FROM advertisers WHERE (UPPER(nickname) = UPPER("'.$_POST['usernameField'].'") OR UPPER(email) = UPPER("'.$_POST['usernameField'].'")) AND password = "'.md5($_POST['passwordField']).'"');
		$number = $result -> fetch_assoc();
		if($number['ofUsers']==1)
		{
			$advertiserRaw = $data -> query('SELECT * FROM advertisers INNER JOIN membership ON membership.user=advertisers.id WHERE (UPPER(nickname) = UPPER("'.$_POST['usernameField'].'") OR UPPER(email) = UPPER("'.$_POST['usernameField'].'")) AND password = "'.md5($_POST['passwordField']).'"');
			if($advertiser = $advertiserRaw -> fetch_array(MYSQLI_ASSOC))
			{
				if($advertiser['paid']==1 && strtotime($advertiser['expiry'])>strtotime(date("Y-m-d")))
				{
					$_SESSION['loggedId'] = $advertiser['user'];
					$loggedIn = 1;
					if($advertiser['suspended']==1)
					{
						$suspendedNotice=1;
					}
				}
				else
				{
					$checkMembership = 1;
				}
			}
			else
			{
				$checkMembership = 1;
			}
		}
	}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#">
	<head>
		<?php
			$country_raw = $data -> query('SELECT * FROM countries WHERE id = '.$currentCountry);
			$country = $country_raw -> fetch_array(MYSQLI_ASSOC);
		?>
   		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   		<?php
   			if(isset($_GET['location']) && $_GET['location']!=0)
   			{
	   			if(isset($_GET['city']) && $_GET['city']!=0)
	   			{
		   			$number = $data -> query('SELECT COUNT(*) AS ofInfo FROM locations_info WHERE location_id=0 AND city_id='.$_GET['city']);
		   			$inf = $data -> query('SELECT * FROM locations_info WHERE location_id=0 AND city_id='.$_GET['city']);
	   			}
	   			else
	   			{
	   				$number = $data -> query('SELECT COUNT(*) AS ofInfo FROM locations_info WHERE location_id='.$_GET['location'].' AND city_id=0');
	   				$inf = $data -> query('SELECT * FROM locations_info WHERE location_id='.$_GET['location'].' AND city_id=0');
	   			}
   			}
   			else
   			{
		   		$number = $data -> query('SELECT COUNT(*) AS ofInfo FROM locations_info WHERE location_id=0 AND city_id=0 AND country='.$country['id']);
		   		$inf = $data -> query('SELECT * FROM locations_info WHERE location_id=0 AND city_id=0 AND country='.$country['id']);
   			}
   			$info['description']='';
   			$info['keywords']='';
   			$info['title']='Escort Central - Escort Services in '.$country['name'].', Private Escorts & Escort Agencies';
   			$info['h1']='';
   			$info['text']='';
   			$ng = $number -> fetch_assoc();
   			if($ng['ofInfo']!=0)
   			{
   				$info = $inf -> fetch_array(MYSQLI_ASSOC);
   			}
   		?>
		<title><?php echo $info['title'];?></title>
   		<meta name="description" content="<?php echo $info['description'];?>" />
   		<meta name="keywords" content="<?php echo $info['keywords'];?>" />
		<script type="text/javascript">
			<!--
				var server = "<?php echo $_SERVER['HTTP_HOST'];?>";
				var numberOfUsers = <?php 
					$numberR = $data -> query('SELECT COUNT(*) AS ofProfiles FROM advertisers');
					$number = $numberR -> fetch_assoc();
					$numberOfUsers = $number['ofProfiles'];
					echo $numberOfUsers;
				?>;
			//-->
		</script>
   		<script type="text/javascript" src="js/jquery.js"></script>
   		<script type="text/javascript" src="js/start_scripts.js"></script>
		<link rel="stylesheet" media="screen" type="text/css" title="ECStyle" href="design/style.css" />
		<!-- Start Alexa Certify Javascript -->
		<script type="text/javascript">
		_atrk_opts = { atrk_acct:"EA37j1a4ZP00Of", domain:"escortcentral.com.au",dynamic: true};
		(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();
		</script>
		<noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=EA37j1a4ZP00Of" style="display:none" height="1" width="1" alt="" /></noscript>
		<!-- End Alexa Certify Javascript --> 
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		 
		  ga('create', 'UA-51240646-1', 'escortcentral.com.au');
		  ga('send', 'pageview');
		 
		</script>
	</head>
	<body>
		<div id="fb-root"></div>
		<script>(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)) return;
			js = d.createElement(s); js.id = id;
			js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
			fjs.parentNode.insertBefore(js, fjs);}
			(document, 'script', 'facebook-jssdk'));</script>
		<script type="text/javascript">
			(function() {
			var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
			po.src = 'https://apis.google.com/js/plusone.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
			})();
		</script>
		<?php
			if(isset($suspendedNotice) && $suspendedNotice==1)
			{
				?>
					<script type="text/javascript">
						<!--
							alert('Your account is suspended, it is not visible to anyone using the site.');
						//-->
					</script>
				<?php
			}
			if(isset($reload) && $reload==1)
			{	
				?>
					<script type="text/javascript">
						<!--
							window.location = "http://<?php echo $_SERVER['HTTP_HOST'];?>";
						//-->
					</script>
				<?php
			}
		?>
		<div onclick="if(mouseOverPopup==0) { <?php if(!preg_match('#trident#', $_SERVER['HTTP_USER_AGENT'])) { echo 'hidePopup();'; } ?> }" id="popupDiv">
			<div onmouseout="mouseOverPopup=0;" onmouseover="mouseOverPopup=1;" id="popupWindow">
				<div id="popupWindowTopBar"><span id="popupWindowTitle"></span><img src="design/cross.png" id="closePopupWindow" alt="Close" onclick="hidePopup();" /></div>
				<div id="popupWindowContent"></div>
			</div>
		</div>
		<div style="width: 940px; position: relative; top: -30px; margin: auto;">
			<div style="position: absolute; right: 0; top: 5px;">
				<div class="fb-like" data-href="https://www.facebook.com/pages/Escort-Central/715298868509962" data-width="60" data-layout="button_count" data-action="like" data-show-faces="true" data-share="false" style="position: relative; top: -4px;"></div>
				<g:plusone size="medium" href="https://plus.google.com/u/0/b/113482270280079006603/113482270280079006603/p"></g:plusone>
				<a href="https://twitter.com/escortcentral" class="twitter-follow-button" data-show-count="true" data-show-screen-name="false" data-lang="en">Follow @escortcentral</a>
				<script type="text/javascript">!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
			</div>
		</div>
		<div id="border">
			<div id="topBannerContent">
				<?php
					if(isset($_SESSION['loggedId']))
					{
						?>
							<input type="button" value="Edit Profile" class="loginButtons" style="top: 15px;" onclick="showPopup('My Profile'); showProfile('profile');" />
							<input id="whiteLoginButton" type="button" value="Logout" class="loginButtons" style="top: 55px;" onclick="window.location='http://<?php echo $_SERVER['HTTP_HOST'];?>/?logout=1';" />
						<?php
					}
					else
					{
						?>
							<input type="button" value="Escort login" class="loginButtons" style="top: 15px;" onclick="loginPrompt('', '');" />
							<input id="whiteLoginButton" type="button" value="Advertise" class="loginButtons" style="top: 55px;" onclick="advertiseInfo();" />
						<?php
					}
				?>
			</div>
			<div id="topMenu">
				<div id="topMenuContent">
					<?php displayMenuItems($currentCountry, new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB)); ?>
				</div>
			</div>
			<div id="wws" <?php if(isset($_GET['search'])||(isset($_GET['location']) && $_GET['location']!='')||(isset($_GET['city']) && $_GET['city']!='')||(isset($_GET['id']) && !preg_match("#[^0-9]#", $_GET['id']))||(isset($_GET['advertise']) && $_GET['advertise']==1)) { ?>style="display: none;"<?php } ?>></div>
			<div id="bodyContent">
				<?php 
					if(isset($_GET['id']) && !preg_match("#[^0-9]#", $_GET['id']))
					{
						?>
							<table style="margin: auto; width: 870px;">
								<tr>
									<td style="vertical-align: top; /*width: 625px;*/">
										<?php
											$result = $data -> query('SELECT COUNT(*) AS ofAdvertisers FROM advertisers WHERE id='.$_GET['id']);
											$number = $result -> fetch_assoc();
											if($number['ofAdvertisers']==1)
											{
												$advertiser_raw = $data -> query('SELECT * FROM advertisers WHERE id='.$_GET['id']);
												$advertiser = $advertiser_raw -> fetch_array(MYSQLI_ASSOC);
												$imageRaw = $data -> query('SELECT * FROM images WHERE user = '.$advertiser['id'].' AND main = 1');
												$regions_raw = $data -> query('SELECT * FROM regions WHERE id= '.$advertiser['region']);
												$region = $regions_raw -> fetch_array(MYSQLI_ASSOC);
												$service_raw = $data -> query('SELECT * FROM advertisers_services INNER JOIN services ON services.id=advertisers_services.service WHERE advertiser = '.$advertiser['id']);
												if($advertiser['city']!='' && $advertiser['city']!=0)
												{
													$cities_raw = $data -> query('SELECT * FROM cities WHERE id= '.$advertiser['city']);
													$city = $cities_raw -> fetch_array(MYSQLI_ASSOC);
												}
												?>
													<div id="escortProfilePage">
														<div style="float: left; height: 100%; max-width: 315px;">
															<div class="noImageOnProfile">
																<div id="displayedImage" style="width: 100%; height: 100%; <?php if($image = $imageRaw -> fetch_array(MYSQLI_ASSOC)) { ?>background-position: center; background-image: url('images/<?php echo $image['file'];?>'); background-repeat: no-repeat; background-size: <?php if($image['width']>$image['height']) { ?>auto 100%<?php } else { ?>100% auto<?php } ?>;<?php } ?>" >
																</div>
															</div>
															<?php 
																$imagesRaw = $data -> query('SELECT * FROM images WHERE user = '.$advertiser['id'].' AND main = 0 AND banner = 0');
																$i = 0;
																while($currentImage=$imagesRaw -> fetch_array(MYSQLI_ASSOC))
																{
																	?>
																		<div id="image<?php echo $i;?>" style="cursor: pointer; float: left; width: 90px; margin-right: 15px; margin-top: 15px; height: 90px; background-color: black; background-position: center; background-image: url('images/<?php echo $currentImage['file'];?>'); background-repeat: no-repeat; background-size: <?php if($currentImage['width']>$currentImage['height']) { ?>auto 100%<?php } else { ?>100% auto<?php } ?>;" onclick="var tempBgSize = document.getElementById('displayedImage').style.backgroundSize; var tempBgImage = document.getElementById('displayedImage').style.backgroundImage; document.getElementById('displayedImage').style.backgroundSize = this.style.backgroundSize; document.getElementById('displayedImage').style.backgroundImage = this.style.backgroundImage; this.style.backgroundSize = tempBgSize; this.style.backgroundImage = tempBgImage;"></div>
																	<?php
																	$i++;
																}
															?>
														</div>
														<div style="min-height: <?php if($i==0) { echo '300'; } else if($i<4) { echo '385'; } else if($i<7) { echo '490'; } else if($i<10) { echo '595'; } else { echo '700'; } ?>px; margin-left: 315px;">
															<?php
																$agency = 0;
																$child = 0;
																if($advertiser['parent']!=0)
																{
																	$child = 1;
																	$agency = 1;
																	$agencyInfRaw = $data -> query('SELECT * FROM advertisers WHERE id = '.$advertiser['parent']);
																	$parentInf = $agencyInfRaw -> fetch_array(MYSQLI_ASSOC);
																	$advertiser['email'] = $parentInf['email'];
																	$advertiser['website'] = $parentInf['website'];
																	$advertiser['facebook'] = $parentInf['facebook'];
																	$advertiser['twitter'] = $parentInf['twitter'];
																	$advertiser['phone'] = $parentInf['phone'];
																	$imagesRaw = $data -> query('SELECT * FROM images WHERE user = '.$advertiser['parent'].' AND banner=1');
																	if($image = $imagesRaw -> fetch_array(MYSQLI_ASSOC))
																	{
																		?>
																			<img style="width: 100%;" src="http://<?php echo $_SERVER['HTTP_HOST'];?>/images/<?php echo $image['file'];?>" alt="Agency banner" />
																		<?php
																	}
																}
																else
																{
																	$result = $data -> query('SELECT COUNT(*) AS ofAgencies FROM membership WHERE user = '.$advertiser['id'].' AND UPPER(type)="AGENCY"');
																	$number = $result -> fetch_assoc();
																	if($number['ofAgencies']==1)
																	{
																		$agency = 1;
																		$imagesRaw = $data -> query('SELECT * FROM images WHERE user = '.$advertiser['id'].' AND banner=1');
																		if($image = $imagesRaw -> fetch_array(MYSQLI_ASSOC))
																		{
																			?>
																				<img style="width: 100%;" src="http://<?php echo $_SERVER['HTTP_HOST'];?>/images/<?php echo $image['file'];?>" alt="Agency banner" />
																			<?php
																		}
																	}
																}
																function showContInf($fb, $tt, $ws, $ph, $em, $ag, $ch)
																{
																	?>
																		<div style="margin-top: 10px; width: 360px;">
																			Contact <?php if($ag==0) { ?>Me<?php } else if($ch==1) { ?>My Agency<?php } ?><br />
																			<div style="float: left; width: 220px; height: 100px; font-size: 12px; line-height: 20px; margin-right: 10px;">
																				E-mail: <?php echo $em;?><br />
																				<?php if($ph!='') { ?>Phone: <?php echo $ph;?><br /><?php } ?>
																				<?php if($ws!='') { ?>Website: <a href="<?php if(!preg_match("#^https?://.+#", $ws)) { echo "http://"; } echo $ws;?>" target="_blank"><?php echo $ws;?></a><?php } ?>
																			</div>
																			<div style="height: 100px; font-size: 12px; line-height: 20px;">
																				<?php if($fb!='') { ?><a href="<?php if(!preg_match("#^https?://.+#", $fb)) { echo "http://"; } echo $fb;?>" target="_blank"><img src="http://<?php echo $_SERVER['HTTP_HOST'];?>/design/fb.png" style="height: 20px;" alt="Facebook" /></a><br /><?php } ?>
																				<?php if($tt!='') { ?><a href="<?php if(!preg_match("#^https?://.+#", $tt)) { echo "http://"; } echo $tt;?>" target="_blank"><img src="http://<?php echo $_SERVER['HTTP_HOST'];?>/design/tt.png" style="height: 20px;" alt="Twitter" /></a><?php } ?>
																			</div>
																		</div>
																	<?php
																}
																if($agency==1)
																{
																	showContInf($advertiser['facebook'], $advertiser['twitter'], $advertiser['website'], $advertiser['phone'], $advertiser['email'], $agency, $child);
																}
															?>
															<span style="font-weight: bold; font-size: 20px;">
																<?php
																	echo $advertiser['nickname'];
																?>
															</span>
															<br /><br />
															<?php 
																if(!($agency==1 && $child==0))
																{
																	?>
																		<table id="profileInfoTable">
																			<tr>
																				<td>
																					Location: 
																				</td>
																				<td class="right">
																					<?php if($advertiser['city']!='' && $advertiser['city']!=0) { echo $city['name'].', '; } echo $region['name'];?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['nationality']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Nationality: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['nationality'];
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['ethnicity']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Ethnicity: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['ethnicity'];
																				?>
																				</td>
																			</tr>
																			<tr>
																				<td>
																					Gender: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['gender'];
																				?>
																				</td>
																			</tr>
																			<?php 
																				$nos = $data -> query('SELECT COUNT(*) AS ofServices FROM advertisers_services INNER JOIN services ON services.id=advertisers_services.service WHERE advertiser = '.$advertiser['id']);
																				$numberOS = $nos -> fetch_assoc();
																			?>
																			<tr <?php if($numberOS['ofServices']==0) { ?>style="display: none;"<?php } ?>>
																				<td>
																					Services: 
																				</td>
																				<td class="right">
																				<?php 
																					while($service = $service_raw -> fetch_array(MYSQLI_ASSOC))
																					{
																						echo $service['name'].'<br />';
																					}
																				?>
																				</td>
																			</tr>
																			<tr>
																				<td>
																					Age: 
																				</td>
																				<td class="right">
																					<?php 
																						$birthDate = new DateTime($advertiser['birthDate']." 00:00:00");
																						if(date("m")>($birthDate->format("m")) || (date("m")==($birthDate->format("m")) && date("d")>($birthDate->format("d"))))
																						{
																							$age = date("Y") - ($birthDate->format("Y"));
																						}
																						else
																						{
																							$age = date("Y") - ($birthDate->format("Y")) - 1;
																						}
																						echo $age;
																					?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['eyeColour']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Eye colour: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['eyeColour'];
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['hair']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Hair: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['hair'];
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['height']==''||$advertiser['height']==0) { ?>style="display: none;"<?php } ?>>
																				<td>
																					Height: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['height'].' cm';
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['bodyType']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Body type: 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['bodyType'];
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['dressSize']==''||($advertiser['dressSize']==0&&$advertiser['dressSize']!='Zero')) { ?>style="display: none;"<?php } ?>>
																				<td>
																					<?php if($advertiser['gender']=='male') { echo "S"; } else { echo "Dress s"; } ?>ize (US): 
																				</td>
																				<td class="right">
																				<?php 
																					echo $advertiser['dressSize'];
																				?>
																				</td>
																			</tr>
																			<tr <?php if($advertiser['bustSize']=='') { ?>style="display: none;"<?php } ?>>
																				<td>
																					Bust size: 
																				</td>
																				<td class="right">
																				<?php 
																					if($advertiser['gender']!="male")
																					{
																						echo $advertiser['bustSize'];
																					}
																					else
																					{
																						echo "NA";
																					}
																				?>
																				</td>
																			</tr>
																			<tr>
																				<td>
																					Shaved: 
																				</td>
																				<td class="right">
																				<?php 
																					if($advertiser['shaved']==1)
																					{
																						echo "yes";
																					}
																					else
																					{
																						echo "no";
																					}
																				?>
																				</td>
																			</tr>
																			<tr>
																				<td>
																					Smoke: 
																				</td>
																				<td class="right">
																				<?php 
																					if($advertiser['smoke']==1)
																					{
																						echo "yes";
																					}
																					else
																					{
																						echo "no";
																					}
																				?>
																				</td>
																			</tr>
																			<tr>
																				<td>
																					Disable friendly: 
																				</td>
																				<td class="right">
																				<?php 
																					if($advertiser['disableFriendly']==1)
																					{
																						echo "yes";
																					}
																					else
																					{
																						echo "no";
																					}
																				?>
																				</td>
																			</tr>
																		</table>
																	<?php
																}
															?>
															<table id="workTable">
															<?php
																$result = $data -> query('SELECT COUNT(*) AS available FROM advertisers_availability WHERE advertiser = '.$advertiser['id']);
																$number = $result -> fetch_assoc();
															?>
																<tr>
																	<td>
																	<?php 
																		if($number['available']!=0) 
																		{ 
																			?>
																					<?php
																						if($number['available']!=0)
																						{
																							echo "Availability";
																						}
																					?>
																				</td>
																				<td class="right">
																			<?php
																		}
																	?>
																		<?php
																			$result = $data -> query('SELECT COUNT(*) AS rates FROM rates WHERE user = '.$advertiser['id']);
																			$numbers = $result -> fetch_assoc();
																			if($numbers['rates']!=0)
																			{
																				echo "Rates";
																			}
																		?>
																	</td>
																</tr>
																<tr style="font-size: 12px;">
																	<td>
																	<?php 
																		if($number['available']!=0) 
																		{ 
																			?>
																					<table style="border-collapse: collapse; margin: 0; padding: 0;">
																						<?php 
																							$availability_raw = $data -> query('SELECT * FROM advertisers_availability WHERE advertiser='.$advertiser['id'].' ORDER BY day');
																							while($available = $availability_raw -> fetch_array(MYSQLI_ASSOC))
																							{
																								$days=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
																								echo '<tr><td><span style="color: grey;">'.$days[$available['day']].'</span> </td><td>'.$available['fromTime'].' - '.$available['toTime'].'</td></tr>';
																							}
																						?>
																					</table>
																				</td>
																				<td class="right">
																			<?php
																		}
																	?>
																		<?php 
																			$rates_raw = $data -> query('SELECT * FROM rates WHERE user='.$advertiser['id'].' ORDER BY price');
																			while($rate = $rates_raw -> fetch_array(MYSQLI_ASSOC))
																			{
																				if($rate['hours']==0)
																				{
																					echo '$'.sprintf('%0.2f', $rate['price']).' for '.$rate['minutes'].' min<br />';
																				}
																				else if($rate['minutes']==0)
																				{
																					echo '$'.sprintf('%0.2f', $rate['price']).' for '.$rate['hours'].' hour(s)<br />';
																				}
																				else if($rate['minutes']!=0)
																				{
																					echo '$'.sprintf('%0.2f', $rate['price']).' for '.$rate['hours'].' hour(s) '.$rate['minutes'].' min<br />';
																				}
																			}
																		?>
																	</td>
																</tr>
															</table>
															<?php 
															if(preg_match("#[^ \n]#", $advertiser['description']))
															{
																?>
																	<div>
																	<br />
																		About <?php if($agency==0||$child==1) { ?>Me<?php } ?><br />
																		<span style="font-size: 12px;"><?php echo preg_replace("#\n#", "<br />", htmlspecialchars($advertiser['description']));?></span>
																	</div>
																<?php
															}
															?>
															<?php
																if($agency==0)
																{
																	showContInf($advertiser['facebook'], $advertiser['twitter'], $advertiser['website'], $advertiser['phone'], $advertiser['email'], $agency, $child);
																}
															?>
														</div>
													</div>
												<?php
											}
											else
											{
												?>
													<div id="escortProfilePage">
														Sorry, the profile you are trying to reach was not found.<br />
														It has either never existed or been deleted.
														<br /><br />
														<a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/">Go to Home Page</a>
													</div>
												<?php
											}
											?>
									</td>
									<?php
										if(isset($number['ofAdvertisers']) && $number['ofAdvertisers']!=1)
										{
											?>
												<td style="vertical-align: top;">
													<?php
														showSearchDiv(new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB), $currentCountry);
													?>
												</td>
											<?php
										}
									?>
								</tr>
							</table>
						<?php
					}
					else if(isset($_GET['advertise']) && $_GET['advertise']==1)
					{
						if(isset($_GET['freeM']) && $_GET['freeM']==1 && $numberOfUsers<100)
						{
							?>
								<script type="text/javascript">
									<!--
										var freeGrant = 1;
									//-->
								</script>
							<?php
						}
						?>
							<table id="pricesTable">
								<tr id="topRow">
									<td class="leftColumn" style="font-weight: bold;">
										Plans
									</td>
									<td id="gold">
										Gold
									</td>
									<td id="platinum">
										Platinum
									</td>
									<td id="agency">
										Agency
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Profiles
									</td>
									<td class="gold">
										1
									</td>
									<td class="platinum">
										1
									</td>
									<td class="agency">
										20
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Photos
									</td>
									<td class="gold">
										8
									</td>
									<td class="platinum">
										12
									</td>
									<td class="agency">
										12 each
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Social Media Promotion
									</td>
									<td class="gold">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
									<td class="platinum">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
									<td class="agency">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Link to your personal website
									</td>
									<td class="gold">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
									<td class="platinum">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
									<td class="agency">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Featured listing on Home page
									</td>
									<td class="gold">
										<img src="../design/no.png" alt="no" class="no" />
									</td>
									<td class="platinum">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
									<td class="agency">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
										Logo and banner on each profile
									</td>
									<td class="gold" style="border-radius: 0 0 0 5px;">
										<img src="../design/no.png" alt="no" class="no" />
									</td>
									<td class="platinum">
										<img src="../design/no.png" alt="no" class="no" />
									</td>
									<td class="agency" style="border-radius: 0 0 5px 0;">
										<img src="../design/yes.png" alt="yes" class="yes" />
									</td>
								</tr>
								<tr>
									<td class="leftColumn">
									</td>
									<td>
										<input type="button" class="signUpButtons" value="<?php if(isset($_GET['freeM']) && $_GET['freeM']==1 && $numberOfUsers<100) { echo 'Signup for free!'; } else { echo 'Sign up for $49.99/month'; } ?>" onclick="register('Gold');" />
									</td>
									<td>
										<input type="button" class="signUpButtons" value="<?php if(isset($_GET['freeM']) && $_GET['freeM']==1 && $numberOfUsers<100) { echo 'Signup for free!'; } else { echo 'Sign up for $59.99/month'; } ?>" onclick="register('Platinum');" />
									</td>
									<td>
										<input type="button" class="signUpButtons" value="<?php if(isset($_GET['freeM']) && $_GET['freeM']==1 && $numberOfUsers<100) { echo 'Signup for free!'; } else { echo 'Sign up for $199.99/month'; } ?>" onclick="register('Agency');" />
									</td>
								</tr>
							</table>
						<?php
					}
					else if(isset($_GET['search']))
					{
						?>
							<table style="margin: auto; width: 930px;">
								<tr>
									<td style="vertical-align: top; width: 625px;">
										<?php 
											if($info['h1']!='')
											{
												?>
													<h1 id="mainH1"><?php echo $info['h1'];?></h1>
												<?php
											}
											if($info['text']!='')
											{
												?>
													<p id="mainDesc"><?php echo $info['text'];?></p>
												<?php
											}
											$city = 0;
											$location = 0;
											$services = 0;
											$gender = '';
											$postCode = '';
											if(isset($_GET['services']))
											{
												$services = $_GET['services'];
											}
											if(isset($_GET['gender']))
											{
												$gender = $_GET['gender'];
											}
											if(isset($_GET['postCode']))
											{
												$postCode = $_GET['postCode'];
											}
											if(isset($_GET['location']))
											{
												$location = $_GET['location'];
												if(isset($_GET['city']))
												{
													$city = $_GET['city'];
												}
											}
											if(isset($_GET['page']) && !(preg_match("#[^0-9]#", $_GET['page'])) && $_GET['page']!=0 && $_GET['page']!='')
											{
												$page = $_GET['page'];
											}
											else
											{
												$page = 1;
											}
											showResults($location, $city, $_GET['search'], $services, $gender, $postCode, $currentCountry, $page, new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB));
										?>
									</td>
									<td style="vertical-align: top;">
										<?php
											showSearchDiv(new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB), $currentCountry);
										?>
									</td>
								</tr>
							</table>
						<?php
					}
					else if(isset($_GET['location']))
					{
						?>
							<table style="margin: auto; width: 930px;">
								<tr>
									<td style="vertical-align: top; width: 625px;">
										<?php 
											if($info['h1']!='')
											{
												?>
													<h1 id="mainH1"><?php echo $info['h1'];?></h1>
												<?php
											}
											if($info['text']!='')
											{
												?>
													<p id="mainDesc"><?php echo $info['text'];?></p>
												<?php
											}
										?>
										<?php
											$city = 0;
											if(isset($_GET['city']))
											{
												$city = $_GET['city'];
											}
											if(isset($_GET['page']) && !(preg_match("#[^0-9]#", $_GET['page'])) && $_GET['page']!=0 && $_GET['page']!='')
											{
												$page = $_GET['page'];
											}
											else
											{
												$page = 1;
											}
											showResults($_GET['location'], $city, '', 0, '', '', $currentCountry, $page, new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB));
										?>
									</td>
									<td style="vertical-align: top;">
										<?php
											showSearchDiv(new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB), $currentCountry);
										?>
									</td>
								</tr>
							</table>
						<?php
					}
					else
					{
						?>
							<table style="margin: auto; width: 930px;">
								<tr>
									<td style="vertical-align: top; width: 625px;">
										<?php 
											if($info['h1']!='')
											{
												?>
													<h1 id="mainH1"><?php echo $info['h1'];?></h1>
												<?php
											}
											if($info['text']!='')
											{
												?>
													<p id="mainDesc"><?php echo $info['text'];?></p>
												<?php
											}
										?>
										<?php
											displayFeatured($currentCountry, new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB));
										?>
									</td>
									<td style="vertical-align: top;">
										<?php
											showSearchDiv(new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB), $currentCountry);
										?>
									</td>
								</tr>
							</table>
							<div id="SEOText">
								<h2>Hire Escort Services in Australia</h2>

								<p>We have made it easy for you to browse our website.  Simply use the
								search box or click on your state to view all of our escort listings.</p>

								<p>Call them what you like, prostitute, whore, slut, sex worker, call girl,
								companion or escort. We have the perfect girl, guy or tranny for you.</p>

								<h2>Why Hire Independent or Private Escorts?</h2>

								<p>If you are looking for fetish escorts eg. bdsm, older women, foot,
								lingerie, or body hair fetishes, I suggest you look for an Independent /
								Private Escort.</p>

								<p>If you are a little nervous, just relax, these girls/guys &amp; tranny's know
								what they are doing.  They are very sexy &amp; discreet escorts</p>

								<h2>Why Hire Escort Agencies?</h2>

								<p>To be sure that your escort is legitimate, I would suggest that you use
								an Escort Agency, as they do regular check ups, and must take responsibility
								for their girls.  You can be sure that Agency girls will be of age. </p>

								<h2>Our Sexy Escorts</h2>
								<p>We have listings of some of the most elite escorts in Australia, &amp; if you
								like Asian escorts, have a look at our Sydney listings, you will find plenty
								of sexy girls there. </p>
							</div>
						<?php
					}
					if(isset($_GET['confirm']) && isset($_GET['id']) && $_GET['id']!='')
					{
						$result = $data -> query('SELECT COUNT(*) AS ofUsers FROM advertisers  WHERE id='.$_GET['confirm'].' AND password="'.$_GET['id'].'" AND parent=0');
						$number = $result -> fetch_assoc();
						$user_raw = $data -> query('SELECT * FROM advertisers INNER JOIN membership ON membership.user=advertisers.id WHERE advertisers.id='.$_GET['confirm'].' AND password="'.$_GET['id'].'" AND parent=0 AND expiry+0 >CURDATE()+0');
						if($user=$user_raw -> fetch_array(MYSQLI_ASSOC))
						{
							if($user['paid']==1)
							{
								?>
									<script type="text/javascript">
										<!--
											alert('This account is already active');
										//-->
									</script>
								<?php
							}
							else
							{
								?>
									<script type="text/javascript">
										<!--
											showPopup("Payment");
											createMembership("<?php echo $user['type'];?>", <?php echo $user['user'];?>, <?php echo $user['autoRenew'];?>, "<?php echo $user['password'];?>");
										//-->
									</script>
								<?php
							}
						}
						else if($number['ofUsers']==1)
						{
							$user_raw = $data -> query('SELECT * FROM advertisers WHERE id='.$_GET['confirm'].' AND password="'.$_GET['id'].'" AND parent=0');
							$user=$user_raw -> fetch_array(MYSQLI_ASSOC);
							$data -> query('DELETE FROM membership WHERE user='.$user['id']);
							?>
								<script type="text/javascript">
									<!--
										selectNewMembership(<?php echo $user['id'];?>, 0);
									//-->
								</script>
							<?php
							//If agency, sub accounts have platinum but can't change it
						}
					}
					else if(isset($_GET['setup']) && isset($_GET['code']))
					{
						if(isset($_SESSION['loggedId']))
						{
							unset($_SESSION['loggedId']);
						}
						$setupRaw = $data -> query('SELECT * FROM advertisers WHERE id='.$_GET['setup'].' AND nickname=""');
						if($setup = $setupRaw -> fetch_array(MYSQLI_ASSOC))
						{
							if(md5($setup['email'])==$_GET['code'])
							{
								?>
									<script type="text/javascript">
										<!--
											showPopup('Setup your account');
											setupAccount(<?php echo $setup['id'];?>, '<?php echo $_GET['code'];?>');
										//-->
									</script>
								<?php
							}
						}
					}
					else if(isset($_GET['reset']) && isset($_GET['id']) && $_GET['id']!='')
					{
						$setupRaw = $data -> query('SELECT * FROM advertisers WHERE id='.$_GET['reset'].' AND password="'.$_GET['id'].'"');
						if($setup = $setupRaw -> fetch_array(MYSQLI_ASSOC))
						{
							?>
								<script type="text/javascript">
									<!--
										resetPW(<?php echo $setup['id'];?>, '<?php echo $_GET['id'];?>');
									//-->
								</script>
							<?php
						}
					}
				?>
				<div id="bottomBar">
					<a href="javascript:showPopup('Terms and Conditions');showTAC();">Terms &amp; conditions</a>
					&nbsp;&nbsp;&nbsp;
					<a href="javascript:showPopup('Contact Us');showContact('', '', '');">Contact us</a>
					&nbsp;&nbsp;&nbsp;
					<?php
						$lawRaw = $data ->query('SELECT * FROM countries WHERE id='.$currentCountry);
						$law = $lawRaw -> fetch_array(MYSQLI_ASSOC);
					?>
					<a href="<?php echo $law['lawUrl'];?>" target="_blank"><?php echo $law['lawName'];?></a>
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					© Copyright 2010 - 2013 Escort Central
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
				</div>
			</div>
		</div>
		<?php 
			if(isset($checkMembership) && $checkMembership==1)
			{
				$user_raw = $data -> query('SELECT * FROM advertisers INNER JOIN membership ON membership.user=advertisers.id WHERE UPPER(nickname)=UPPER("'.$_POST['usernameField'].'") AND password = "'.md5($_POST['passwordField']).'" AND expiry+0 >CURDATE()+0');
				if($user=$user_raw -> fetch_array(MYSQLI_ASSOC))
				{
					if($user['parent']==0)
					{
						?>
							<script type="text/javascript">
								<!--
									showPopup("Payment");
									createMembership("<?php echo $user['type'];?>", <?php echo $user['user'];?>, <?php echo $user['autoRenew'];?>, '<?php echo $user['password'];?>');
								//-->
							</script>
						<?php
					}
					else
					{
						?>
							<script type="text/javascript">
								<!--
									alert('Your membership has expired, please ask your administrator to renew it in order to keep using you account');
								//-->
							</script>
						<?php
					}
				}
				else
				{
					$user_raw = $data -> query('SELECT * FROM advertisers WHERE UPPER(nickname)=UPPER("'.$_POST['usernameField'].'") AND password = "'.md5($_POST['passwordField']).'"');
					$user=$user_raw -> fetch_array(MYSQLI_ASSOC);
					if($user['parent']==0)
					{
						$data -> query('DELETE FROM membership WHERE user='.$user['id']);
						?>
							<script type="text/javascript">
								<!--
									selectNewMembership(<?php echo $user['id'];?>, 0);
								//-->
							</script>
						<?php
					}
					else
					{
						?>
							<script type="text/javascript">
								<!--
									alert('Your membership has expired, please ask your administrator to renew it in order to keep using you account');
								//-->
							</script>
						<?php
					}
				}
			}
			else if(isset($_POST['usernameField']) && !isset($_SESSION['loggedId'])) 
			{ 
				?>
					<script type="text/javascript">
						<!--
							loginPrompt("<?php echo htmlspecialchars($_POST['usernameField']); ?>", "<?php echo htmlspecialchars($_POST['passwordField']); ?>");
						//-->
					</script>
				<?php
			} 
			if(isset($_GET['paid']) && $_GET['paid']==1 && isset($_SESSION['loggedId']) && $_SESSION['loggedId']!=0)
			{
				?>
					<script type="text/javascript">
						<!--
							welcome = 1;
							showPopup('My Profile'); 
							showProfile('profile');
						//-->
					</script>
				<?php
			}
			else if(isset($loggedIn) && $loggedIn==1 && (!isset($suspendedNotice)||$suspendedNotice==0) && isset($_SESSION['loggedId']) && $_SESSION['loggedId']!=0)
			{
				?>
					<script type="text/javascript">
						<!--
							showPopup('My Profile'); 
							showProfile('profile');
						//-->
					</script>
				<?php
			}
			else if(isset($_GET['elogin']) && $_GET['elogin']==1)
			{
				?>
					<script type="text/javascript">
						<!--
							loginPrompt('', '');
						//-->
					</script>
				<?php
			}
		?>
		<script type="text/javascript">
			<!--
				<?php 
					if(isset($_GET['error']) && $_GET['error']==404)
					{
						?>
							var address = window.location.href;
							if ( history.pushState ) history.pushState( {}, document.title, address.replace(/\?error=404/, "") );
							showPopup('Error 404');
							document.getElementById("popupWindowContent").innerHTML = '<div style="padding: 20px;">The page you are trying to reach was not found. You were redirected to our home page.</div><div style="text-align: right; padding-bottom: 20px; padding-right: 20px;"><input type="button" value="Okay" onclick="hidePopup();" /></div>';
						<?php
					}
					else
					{
						?>
							var diesette = window.location.hash;
							if(diesette=='#freemembership' && numberOfUsers<100)
							{
								advertiseInfo();
							}
							else if(diesette=='#freemembership')
							{
								alert('Sorry, this offer has now expired. Thank you for your interest in Escort Central');
							}
						<?php
					}
				?>
			//-->
		</script>
	</body>
</html>