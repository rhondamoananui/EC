<?php
	if(isset($root))
	{
		error_reporting(E_ALL);
		ini_set('display_errors', 1);
		session_start();
		if(isset($_GET['logout']))
		{
			session_destroy();
			if(!isset($_GET['setup']) && !isset($_GET['code']))
			{
				$reload = 1;
			}
		}
		$QL_Host = "50.62.209.14:3306";
		$QL_User = "escortcentral";
		$QL_Password = "1a2b3c4d5e6f";
		$QL_DB = "escort_central";
		$currentCountry = 2;
		$helpEmail = 'admin@escortcentral.com.au';
		$db = new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB);
		$chronDoneR = $db -> query('SELECT * FROM chron WHERE id=1');
		$chron = $chronDoneR -> fetch_array(MYSQLI_ASSOC);
		if(date('H')==19 && $chron['done']==0)
		{
			$membershipsRaw = $db -> query('SELECT * FROM membership INNER JOIN advertisers ON advertisers.id=membership.user WHERE expiry+0 < CURDATE()+0');
			while($membership = $membershipsRaw -> fetch_array(MYSQLI_ASSOC))
			{
				if($membership['autoRenew']==1)
				{
					$db -> query('UPDATE membership SET paid=0, expiry="'.(date("Y")+1).'-'.date("m-d").'" WHERE user='.$membership['user'].' AND type="'.$membership['type'].'"');
		 			$message = 'Hi '.$membership['fname'].',<br />Your Escort central membership has now expired and been automatically renewed. Please loggin to the site or click the link bellow to proceed to payment and activate your renewed membership:<br /><br />http://'.$_SERVER['HTTP_HOST'].'/?confirm='.$membership['id'].'&id='.$membership['password'];
				}
				else
				{
					$db -> query('DELETE FROM membership WHERE user = '.$membership['user']);
		 			$message = 'Hi '.$membership['fname'].',<br />Your Escort central membership has now expired. Login to the site or click the link bellow if you wish to set up a new membership:<br /><br /><a href="http://'.$_SERVER['HTTP_HOST'].'/?confirm='.$membership['id'].'&id='.$membership['password'].'">http://'.$_SERVER['HTTP_HOST'].'/?confirm='.$membership['id'].'&id='.$membership['password'].'</a>';
				}
				$to      = $membership['email'];
	 			$subject = 'Escort Central Membership Expiry';
	 			$countryRaw = $db -> query('SELECT * FROM countries WHERE id='.$currentCountry);
	 			$country = $countryRaw -> fetch_array(MYSQLI_ASSOC);

	 			$headers = 'From: noreply@escortcentral' . $country['extension'] . "\r\n" .
				'Reply-To: noreply@escortcentral' . $country['extension'] . "\r\n" .
				'Content-Type: text/html; charset="UTF-8";' . "\r\n" .
	 			'X-Mailer: PHP/' . phpversion();

	 			mail($to, $subject, $message, $headers);
			}
			$files = scandir($root.'/images');
			$i = 0;
			while(isset($files[$i]))
			{
				if(preg_match("#\.jpg|\.png|\.gif|\.jpeg#", $files[$i]))
				{
					$result=$db -> query('SELECT COUNT(*) AS ofImages FROM images WHERE file ="'.$files[$i].'"');
					$number = $result -> fetch_assoc();
					if($number['ofImages']==0)
					{
						unlink($root.'/images/'.$files[$i]);
					}
				}
				$i++;
			}
			$db -> query('UPDATE chron SET done=1 WHERE id=1');
		}
		else if(date('H')!=19)
		{
			$db -> query('UPDATE chron SET done=0 WHERE id=1');
		}
	}
	else
	{
		//Error 404
		include $root."/php/error404.php";
	}
?>