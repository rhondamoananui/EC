<?php
	$root = realpath($_SERVER["DOCUMENT_ROOT"]);
	include $root."/php/start.php";
	$data = new mysqli($QL_Host, $QL_User, $QL_Password, $QL_DB);
	if(isset($_POST['description']) && isset($_SESSION['loggedId']))
	{
		if($data -> query('UPDATE advertisers SET description="'.$data -> real_escape_string($_POST['description']).'" WHERE id = '.$_SESSION['loggedId']))
		{
			echo "ok";
		}
		else
		{
			echo "error";
		}
	}
	else
	{
		//error 404
		include $root."/php/error404.php";
	}
?>